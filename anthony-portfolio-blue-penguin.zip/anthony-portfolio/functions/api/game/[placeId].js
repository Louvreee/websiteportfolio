export async function onRequest({ params }) {
  const placeId = String(params.placeId || '');
  if (!/^\d{5,20}$/.test(placeId)) return Response.json({ error: 'Invalid place ID' }, { status: 400 });
  try {
    const universeResponse = await fetch(`https://apis.roblox.com/universes/v1/places/${placeId}/universe`);
    if (!universeResponse.ok) return Response.json({ error: 'Roblox universe lookup failed' }, { status: universeResponse.status });
    const universe = await universeResponse.json();
    if (!universe.universeId) return Response.json({ error: 'Universe not found' }, { status: 404 });
    const [gameResponse, thumbnailResponse] = await Promise.all([
      fetch(`https://games.roblox.com/v1/games?universeIds=${universe.universeId}`),
      fetch(`https://thumbnails.roblox.com/v1/games/icons?universeIds=${universe.universeId}&size=512x512&format=Png&isCircular=false`)
    ]);
    if (!gameResponse.ok) return Response.json({ error: 'Roblox game lookup failed' }, { status: gameResponse.status });
    const gameData = await gameResponse.json();
    const game = gameData.data?.[0];
    if (!game) return Response.json({ error: 'Game data not found' }, { status: 404 });
    let thumbnail = null;
    if (thumbnailResponse.ok) thumbnail = (await thumbnailResponse.json()).data?.[0]?.imageUrl || null;
    return Response.json({ name: game.name, playing: game.playing ?? 0, visits: game.visits ?? 0, creator: game.creator?.name || 'Roblox experience', created: game.created || null, thumbnail }, { headers: { 'Cache-Control': 'public, max-age=45, s-maxage=45' } });
  } catch { return Response.json({ error: 'Upstream request failed' }, { status: 502 }); }
}
