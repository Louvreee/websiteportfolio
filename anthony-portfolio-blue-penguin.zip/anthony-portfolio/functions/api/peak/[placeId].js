export async function onRequest({ params }) {
  const placeId = String(params.placeId || '');
  if (!/^\d{5,20}$/.test(placeId)) return Response.json({ error: 'Invalid place ID' }, { status: 400 });
  try {
    const response = await fetch(`https://www.rolimons.com/game/${placeId}`, { headers: { 'User-Agent': 'Mozilla/5.0 (compatible; AnthonyPortfolioTracker/1.0)' } });
    if (!response.ok) return Response.json({ error: 'Peak data unavailable' }, { status: response.status });
    const html = await response.text();
    const plain = html.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, ' ').replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, ' ').replace(/<[^>]+>/g, ' ').replace(/&nbsp;|&#160;/gi, ' ').replace(/&amp;/gi, '&').replace(/\s+/g, ' ');
    const section = plain.match(/Peak Player Counts\s*\(CCU\)([\s\S]{0,700})/i);
    const match = section?.[1]?.match(/All-Time\s+([\d,]+)/i);
    if (!match) return Response.json({ error: 'Peak not listed' }, { status: 404 });
    return Response.json({ peakCCU: Number(match[1].replace(/,/g, '')) }, { headers: { 'Cache-Control': 'public, max-age=900, s-maxage=900' } });
  } catch { return Response.json({ error: 'Peak data request failed' }, { status: 502 }); }
}
