export async function onRequest({ params }) {
  const code = String(params.code || '');
  if (!/^[a-zA-Z0-9-]{2,40}$/.test(code)) return Response.json({ error: 'Invalid invite code' }, { status: 400 });
  try {
    const response = await fetch(`https://discord.com/api/v10/invites/${encodeURIComponent(code)}?with_counts=true`, { headers: { 'User-Agent': 'AnthonyPortfolioGameTracker/1.0' } });
    if (!response.ok) return Response.json({ error: 'Discord count unavailable' }, { status: response.status });
    const data = await response.json();
    return Response.json({ memberCount: Number.isFinite(data.approximate_member_count) ? data.approximate_member_count : null }, { headers: { 'Cache-Control': 'public, max-age=120, s-maxage=120' } });
  } catch { return Response.json({ error: 'Discord request failed' }, { status: 502 }); }
}
